@echo off
setlocal
title windows_11_auto_setup

echo ==============================================
echo Windows 11 Automatic Setup
echo ==============================================
echo.
echo This script will request administrator permission.
echo.
pause

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "Start-Process powershell.exe -Verb RunAs -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File ""%~dp0windows_11_auto_setup.ps1""'"

endlocal
