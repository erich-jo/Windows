﻿# windows_11_auto_setup.ps1
# Windows 11 automatic setup
# - Windows 10 style right-click context menu
# - Keyboard response / repeat / cursor blink settings
# - Disable USB selective suspend
# - Disable Device Connect / Disconnect sounds
#
# Each individual operation is attempted independently.
# If a registry path/setting is unavailable, the script logs it and continues.

$ErrorActionPreference = "Continue"

$script:LogFile = Join-Path $PSScriptRoot "windows_11_auto_setup.log"

function Log {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message
    Write-Host $line
    Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8
}

function Try-Action {
    param(
        [string]$Name,
        [scriptblock]$Action
    )

    try {
        & $Action
        Log "[OK] $Name"
    }
    catch {
        Log "[SKIP] $Name : $($_.Exception.Message)"
    }
}

Log "==============================================="
Log "Windows 11 automatic setup started"
Log "==============================================="

# ------------------------------------------------
# 1. Windows 10-style right-click context menu
# ------------------------------------------------
Try-Action "Import Windows 10 right-click registry file" {
    $regFile = Join-Path $PSScriptRoot "windows_10_mouse_right_click.reg"

    if (-not (Test-Path -LiteralPath $regFile)) {
        throw "Registry file not found: $regFile"
    }

    $p = Start-Process -FilePath "$env:WINDIR\regedit.exe" `
        -ArgumentList "/s `"$regFile`"" `
        -Wait -PassThru

    if ($p.ExitCode -ne 0) {
        throw "regedit exited with code $($p.ExitCode)"
    }
}

# ------------------------------------------------
# 2. Keyboard response settings
# ------------------------------------------------
$accessibilityKey = "HKCU:\Control Panel\Accessibility\Keyboard Response"
$keyboardKey      = "HKCU:\Control Panel\Keyboard"
$desktopKey       = "HKCU:\Control Panel\Desktop"

# The Accessibility\Keyboard Response values are kept as strings,
# matching the normal Windows registry representation.
Try-Action "Set Keyboard Response - AutoRepeatDelay=100" {
    if (-not (Test-Path $accessibilityKey)) { throw "Registry key not found" }
    Set-ItemProperty -Path $accessibilityKey -Name "AutoRepeatDelay" -Value "100" -ErrorAction Stop
}

Try-Action "Set Keyboard Response - AutoRepeatRate=1" {
    if (-not (Test-Path $accessibilityKey)) { throw "Registry key not found" }
    Set-ItemProperty -Path $accessibilityKey -Name "AutoRepeatRate" -Value "1" -ErrorAction Stop
}

Try-Action "Set Keyboard Response - DelayBeforeAcceptance=0" {
    if (-not (Test-Path $accessibilityKey)) { throw "Registry key not found" }
    Set-ItemProperty -Path $accessibilityKey -Name "DelayBeforeAcceptance" -Value "0" -ErrorAction Stop
}

Try-Action "Set Keyboard Response - Last Valid Wait=0" {
    if (-not (Test-Path $accessibilityKey)) { throw "Registry key not found" }
    Set-ItemProperty -Path $accessibilityKey -Name "Last Valid Wait" -Value "0" -ErrorAction Stop
}

Try-Action "Set Keyboard - KeyboardDelay=0" {
    if (-not (Test-Path $keyboardKey)) { throw "Registry key not found" }
    Set-ItemProperty -Path $keyboardKey -Name "KeyboardDelay" -Value "0" -ErrorAction Stop
}

Try-Action "Set Keyboard - KeyboardSpeed=31" {
    if (-not (Test-Path $keyboardKey)) { throw "Registry key not found" }
    Set-ItemProperty -Path $keyboardKey -Name "KeyboardSpeed" -Value "31" -ErrorAction Stop
}

# Keyboard Control Panel's "Cursor blink rate" is represented by CursorBlinkRate.
# 200 ms is the fastest standard setting exposed by the Windows Keyboard control panel.
Try-Action "Set cursor blink rate to fastest (200 ms)" {
    if (-not (Test-Path $desktopKey)) { throw "Registry key not found" }
    Set-ItemProperty -Path $desktopKey -Name "CursorBlinkRate" -Value "200" -ErrorAction Stop
}

# Refresh the user settings without requiring logoff.
Try-Action "Refresh Windows user parameters" {
    $signature = @'
using System;
using System.Runtime.InteropServices;

public static class Win32Refresh {
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern IntPtr SendMessageTimeout(
        IntPtr hWnd,
        uint Msg,
        UIntPtr wParam,
        IntPtr lParam,
        uint fuFlags,
        uint uTimeout,
        out UIntPtr lpdwResult);
}
'@

    if (-not ("Win32Refresh" -as [type])) {
        Add-Type -TypeDefinition $signature -ErrorAction Stop
    }

    $result = [UIntPtr]::Zero
    [Win32Refresh]::SendMessageTimeout(
        [IntPtr]0xffff,
        0x001A,
        [UIntPtr]::Zero,
        [IntPtr]::Zero,
        0x0002,
        5000,
        [ref]$result
    ) | Out-Null
}

# ------------------------------------------------
# 3. Disable USB selective suspend
# ------------------------------------------------
Try-Action "Disable USB selective suspend (AC)" {
    $output = & powercfg.exe /SETACVALUEINDEX SCHEME_CURRENT SUB_USB USBSELECTIVE 0 2>&1
    if ($LASTEXITCODE -ne 0) { throw ($output -join " ") }
}

Try-Action "Disable USB selective suspend (DC)" {
    $output = & powercfg.exe /SETDCVALUEINDEX SCHEME_CURRENT SUB_USB USBSELECTIVE 0 2>&1
    if ($LASTEXITCODE -ne 0) { throw ($output -join " ") }
}

Try-Action "Apply current power scheme" {
    $output = & powercfg.exe /SETACTIVE SCHEME_CURRENT 2>&1
    if ($LASTEXITCODE -ne 0) { throw ($output -join " ") }
}

# ------------------------------------------------
# 4. Disable Device Connect / Disconnect sounds
# ------------------------------------------------
$connectKey = "HKCU:\AppEvents\Schemes\Apps\.Default\DeviceConnect\.Current"
$disconnectKey = "HKCU:\AppEvents\Schemes\Apps\.Default\DeviceDisconnect\.Current"

Try-Action "Disable Device Connect sound" {
    if (-not (Test-Path $connectKey)) { throw "Registry key not found" }
    Set-ItemProperty -Path $connectKey -Name "(default)" -Value "" -ErrorAction Stop
}

Try-Action "Disable Device Disconnect sound" {
    if (-not (Test-Path $disconnectKey)) { throw "Registry key not found" }
    Set-ItemProperty -Path $disconnectKey -Name "(default)" -Value "" -ErrorAction Stop
}

# Some Windows builds may not expose the event keys until the sound scheme
# has been initialized. In that case the two operations above are skipped.

# ------------------------------------------------
# Apply right-click menu change immediately
# ------------------------------------------------
Try-Action "Restart Windows Explorer" {
    Stop-Process -Name explorer -Force -ErrorAction Stop
    Start-Sleep -Milliseconds 800
    Start-Process explorer.exe
}

Log "==============================================="
Log "Windows 11 automatic setup finished"
Log "Check this log for any [SKIP] items:"
Log $script:LogFile
Log "==============================================="

Write-Host ""
Write-Host "Setup finished. Press Enter to close."
Read-Host
