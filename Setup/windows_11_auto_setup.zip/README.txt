windows_11_auto_setup
======================

Files
-----
windows_11_auto_setup.bat
    Double-click this file to start the automatic setup.

windows_11_auto_setup.ps1
    Main PowerShell automation script.

windows_10_mouse_right_click.reg
    The registry file supplied by the user. It is imported unchanged.

What it changes
---------------
1. Windows 10-style right-click context menu
   - Imports windows_10_mouse_right_click.reg.
   - Restarts Windows Explorer so the change is applied immediately.

2. Keyboard response
   HKCU\Control Panel\Accessibility\Keyboard Response
     AutoRepeatDelay       = 100
     AutoRepeatRate        = 1
     DelayBeforeAcceptance = 0
     Last Valid Wait       = 0

   HKCU\Control Panel\Keyboard
     KeyboardDelay = 0
     KeyboardSpeed = 31

   HKCU\Control Panel\Desktop
     CursorBlinkRate = 200
     (200 ms = fastest standard Keyboard Control Panel cursor blink setting.)

3. USB disconnect/connect sound
   - USB selective suspend disabled for AC and DC power profiles.
   - Device Connect sound set to blank.
   - Device Disconnect sound set to blank.

Skip behavior
-------------
Each setting is handled independently.
If a registry key is unavailable or a command fails, that item is
logged as [SKIP] and the script continues with the next item.

Log
---
windows_11_auto_setup.log

Notes
-----
- Run windows_11_auto_setup.bat rather than directly running the .ps1 file.
- Administrator permission is requested by the .bat launcher.
- The script changes settings for the currently logged-in Windows user.
- It is recommended to close important applications before running it,
  because Windows Explorer is restarted near the end.
